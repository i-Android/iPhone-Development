//
//  TelnetControllerTests.h
//  TelnetControllerTests
//
//  Created by ROBERT TILTON on 1/12/13.
//  Copyright (c) 2013 ROBERT TILTON. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TelnetControllerTests : SenTestCase

@end
